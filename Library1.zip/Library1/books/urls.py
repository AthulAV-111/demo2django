"""
URL configuration for Library project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import views
app_name="books"

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.Home.as_view(),name="homeview"),

    # path('add',views.addbooks,name="addbooks"),
    path('add', views.Addbooks.as_view(), name="addbooks"),
    path('view',views.Viewbooks.as_view(),name="viewbooks"),
    # path('view', views.viewbooks, name="viewbooks"),
    path('bookdetail/<int:i>',views.Bookdetail.as_view(),name="bookdetail"),
    # path('bookdetail/<int:i>',views.bookdetail,name="bookdetail"),
    path('editbook/<int:i>',views.Editbook.as_view(),name="editbook"),
    # path('editbook/<int:i>', views.editbook, name="editbook"),
    path('deletebook/<int:i>',views.Deletebook.as_view(),name="deletebook"),
    # path('deletebook/<int:i>', views.deletebook, name="deletebook"),



]
