from django.shortcuts import render

# Create your views here.

from django.views import View



class Home(View):
    def get(self,request):
        return render(request,'Home.html')

class Register(View):
    def get(self,request):
        return render(request,'register.html')

class Userlogin(View):
    def get(self,request):
        return render(request,'login.html')

class Userlogout(View):
    pass
